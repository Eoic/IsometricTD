﻿interface ISpawnPoint
{
    void SpawnEnemy();
}