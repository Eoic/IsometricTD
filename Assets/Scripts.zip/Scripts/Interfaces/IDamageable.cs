﻿interface IDamageable
{
    void TakeDamage(int damage);
}