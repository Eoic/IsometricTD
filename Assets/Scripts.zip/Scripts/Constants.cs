﻿using UnityEngine;

public class Constants : MonoBehaviour
{
    void Awake()
    {
        
    }
}
