﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthBarFaceCamera : MonoBehaviour
{
    //public GameObject gameCamera;

    void Update()
    {
        //transform.LookAt(gameCamera.transform);
    }
}
